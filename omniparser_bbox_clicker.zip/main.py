\
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import threading
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

from PIL import Image, ImageTk

from omni_detect import run_detect, format_lines, detect_screen_size


def now_tag():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("OmniParser Boxes → Mouse Click Points")
        self.root.geometry("1100x720")

        self.worker = None

        top = ttk.Frame(root)
        top.pack(fill="x", padx=10, pady=8)

        ttk.Label(top, text="Image:").pack(side="left")
        self.img_var = tk.StringVar(value="")
        ttk.Entry(top, textvariable=self.img_var, width=48).pack(side="left", padx=6)
        ttk.Button(top, text="Browse", command=self.pick_image).pack(side="left")

        ttk.Label(top, text="Weights:").pack(side="left", padx=(12, 0))
        self.w_var = tk.StringVar(value=str((Path.cwd() / "weights").resolve()))
        ttk.Entry(top, textvariable=self.w_var, width=36).pack(side="left", padx=6)
        ttk.Button(top, text="Browse", command=self.pick_weights).pack(side="left")

        ttk.Label(top, text="Out:").pack(side="left", padx=(12, 0))
        self.out_var = tk.StringVar(value=str((Path.cwd() / "runs").resolve()))
        ttk.Entry(top, textvariable=self.out_var, width=28).pack(side="left", padx=6)
        ttk.Button(top, text="…", width=3, command=self.pick_out).pack(side="left")

        row = ttk.Frame(root)
        row.pack(fill="x", padx=10, pady=(0, 8))

        ttk.Label(row, text="Icon conf:").pack(side="left")
        self.conf_var = tk.StringVar(value="0.05")
        ttk.Entry(row, textvariable=self.conf_var, width=6).pack(side="left", padx=(6, 12))

        ttk.Label(row, text="Text/Icon overlap IoU:").pack(side="left")
        self.iou_var = tk.StringVar(value="0.70")
        ttk.Entry(row, textvariable=self.iou_var, width=6).pack(side="left", padx=(6, 12))

        ttk.Button(row, text="Detect + Export", command=self.run).pack(side="left")
        self.status_var = tk.StringVar(value="Idle")
        ttk.Label(row, textvariable=self.status_var).pack(side="right")

        sw, sh = detect_screen_size()
        self.info_var = tk.StringVar(value=f"Screen: {sw}×{sh}")
        ttk.Label(root, textvariable=self.info_var).pack(anchor="w", padx=12)

        pane = ttk.Panedwindow(root, orient=tk.HORIZONTAL)
        pane.pack(fill="both", expand=True, padx=10, pady=10)

        left = ttk.Frame(pane)
        right = ttk.Frame(pane)
        pane.add(left, weight=1)
        pane.add(right, weight=1)

        self.preview = ttk.Label(left)
        self.preview.pack(fill="both", expand=True)

        self.txt = scrolledtext.ScrolledText(right)
        self.txt.pack(fill="both", expand=True)
        self.txt.insert("1.0", "1) Run download_weights.bat\n2) Pick an image\n3) Click Detect + Export\n")
        self.txt.configure(state="disabled")

        btns = ttk.Frame(right)
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="Copy selected line", command=self.copy_selected).pack(side="left")

    def set_status(self, s: str):
        self.status_var.set(s)
        self.root.update_idletasks()

    def pick_image(self):
        p = filedialog.askopenfilename(filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.bmp;*.webp"), ("All", "*.*")])
        if p:
            self.img_var.set(p)

    def pick_weights(self):
        p = filedialog.askdirectory()
        if p:
            self.w_var.set(p)

    def pick_out(self):
        p = filedialog.askdirectory()
        if p:
            self.out_var.set(p)

    def show_text(self, s: str):
        self.txt.configure(state="normal")
        self.txt.delete("1.0", tk.END)
        self.txt.insert("1.0", s)
        self.txt.configure(state="disabled")

    def show_image(self, img: Image.Image):
        w = max(200, self.preview.winfo_width() or 520)
        h = max(200, self.preview.winfo_height() or 520)
        iw, ih = img.size
        scale = min(w / iw, h / ih, 1.0)
        disp = img.resize((int(iw * scale), int(ih * scale)), Image.Resampling.LANCZOS)
        tkimg = ImageTk.PhotoImage(disp)
        self.preview.configure(image=tkimg)
        self.preview.image = tkimg

    def run(self):
        if self.worker and self.worker.is_alive():
            messagebox.showwarning("Busy", "Already running.")
            return
        if not self.img_var.get().strip():
            messagebox.showwarning("Missing", "Pick an image first.")
            return
        self.worker = threading.Thread(target=self._worker, daemon=True)
        self.worker.start()

    def _worker(self):
        img_path = Path(self.img_var.get()).expanduser().resolve()
        weights_dir = Path(self.w_var.get()).expanduser().resolve()
        out_root = Path(self.out_var.get()).expanduser().resolve()
        out_root.mkdir(parents=True, exist_ok=True)
        run_dir = out_root / f"run_{now_tag()}"
        run_dir.mkdir(parents=True, exist_ok=True)

        try:
            conf = float(self.conf_var.get().strip() or "0.05")
            iou = float(self.iou_var.get().strip() or "0.70")
        except Exception:
            conf, iou = 0.05, 0.70

        try:
            self.set_status("Detecting...")
            annotated, elems = run_detect(img_path, weights_dir, box_conf=conf, overlap_iou=iou)

            out_img = run_dir / "annotated.png"
            out_txt = run_dir / "boxes.txt"
            annotated.save(out_img)

            lines = format_lines(elems)
            out_txt.write_text("\n".join(lines), encoding="utf-8")

            header = f"Saved:\n- {out_img}\n- {out_txt}\n\nCount: {len(elems)}\n\n"
            self.show_text(header + "\n".join(lines))
            self.show_image(annotated)
            self.set_status("Done")
        except Exception as e:
            self.set_status("Error")
            self.show_text(
                f"Error:\n{e}\n\n"
                "Tips:\n"
                "- Run download_weights.bat first\n"
                "- Install PyTorch from the official site if needed\n"
                "- weights/icon_detect/model.pt must exist\n"
            )

    def copy_selected(self):
        try:
            sel = self.txt.get(tk.SEL_FIRST, tk.SEL_LAST)
        except Exception:
            messagebox.showinfo("Copy", "Select a line in the textbox first.")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(sel)
        self.root.update()


def main():
    root = tk.Tk()
    try:
        style = ttk.Style()
        if "clam" in style.theme_names():
            style.theme_use("clam")
    except Exception:
        pass
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
