\
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
from PIL import Image, ImageDraw, ImageFont


@dataclass
class Element:
    idx: int
    kind: str  # "text" or "icon"
    bbox_img: tuple[int, int, int, int]        # (x1,y1,x2,y2) in image pixels
    center_img: tuple[int, int]                # (cx,cy) in image pixels
    center_screen: tuple[int, int]             # mapped to current screen pixels
    text: str = ""
    conf: float = 0.0


def _iou(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
    inter = iw * ih
    if inter <= 0:
        return 0.0
    area_a = max(0, ax2 - ax1) * max(0, ay2 - ay1)
    area_b = max(0, bx2 - bx1) * max(0, by2 - by1)
    denom = area_a + area_b - inter
    return float(inter / denom) if denom > 0 else 0.0


def _bbox_center(b: tuple[int, int, int, int]) -> tuple[int, int]:
    x1, y1, x2, y2 = b
    return (int(round((x1 + x2) / 2)), int(round((y1 + y2) / 2)))


def detect_screen_size() -> tuple[int, int]:
    try:
        import pyautogui
        w, h = pyautogui.size()
        return int(w), int(h)
    except Exception:
        pass
    try:
        import ctypes
        user32 = ctypes.windll.user32
        return int(user32.GetSystemMetrics(0)), int(user32.GetSystemMetrics(1))
    except Exception:
        return (0, 0)


def load_models(weights_dir: str | Path, ocr_langs: Optional[list[str]] = None):
    weights_dir = Path(weights_dir)
    icon_model = weights_dir / "icon_detect" / "model.pt"
    if not icon_model.exists():
        raise FileNotFoundError(f"Missing icon detector weights: {icon_model}")

    from ultralytics import YOLO
    import easyocr

    yolo = YOLO(str(icon_model))
    reader = easyocr.Reader(ocr_langs or ["en"], gpu=False)
    return yolo, reader


def run_detect(
    image_path: str | Path,
    weights_dir: str | Path,
    box_conf: float = 0.05,
    overlap_iou: float = 0.7,
) -> tuple[Image.Image, list[Element]]:
    image_path = Path(image_path)
    img = Image.open(image_path).convert("RGB")
    w_img, h_img = img.size

    screen_w, screen_h = detect_screen_size()
    if screen_w <= 0 or screen_h <= 0:
        screen_w, screen_h = w_img, h_img

    scale_x = screen_w / w_img
    scale_y = screen_h / h_img

    yolo, reader = load_models(weights_dir)

    # OCR (text)
    np_img = np.array(img)
    ocr = reader.readtext(np_img, detail=1, paragraph=False)
    text_elems: list[tuple[tuple[int, int, int, int], str, float]] = []
    for pts, txt, conf in ocr:
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        x1, y1, x2, y2 = int(min(xs)), int(min(ys)), int(max(xs)), int(max(ys))
        if (x2 - x1) * (y2 - y1) <= 5 or not str(txt).strip():
            continue
        text_elems.append(((x1, y1, x2, y2), str(txt).strip(), float(conf)))

    # Icons (YOLO)
    results = yolo.predict(source=np_img, conf=box_conf, iou=0.1, verbose=False)
    icon_boxes: list[tuple[tuple[int, int, int, int], float]] = []
    if results and results[0].boxes is not None and len(results[0].boxes) > 0:
        xyxy = results[0].boxes.xyxy.cpu().numpy()
        confs = results[0].boxes.conf.cpu().numpy()
        for (x1, y1, x2, y2), c in zip(xyxy, confs):
            b = (int(x1), int(y1), int(x2), int(y2))
            if (b[2] - b[0]) * (b[3] - b[1]) <= 5:
                continue
            icon_boxes.append((b, float(c)))

    # Remove icon boxes overlapping with text boxes
    filtered_icons: list[tuple[tuple[int, int, int, int], float]] = []
    for ibox, ic in icon_boxes:
        if any(_iou(ibox, tbox) >= overlap_iou for (tbox, _, _) in text_elems):
            continue
        filtered_icons.append((ibox, ic))

    elems: list[Element] = []
    idx = 1
    for b, txt, conf in text_elems:
        cx, cy = _bbox_center(b)
        sx, sy = int(round(cx * scale_x)), int(round(cy * scale_y))
        elems.append(Element(idx=idx, kind="text", bbox_img=b, center_img=(cx, cy), center_screen=(sx, sy), text=txt, conf=conf))
        idx += 1
    for b, conf in filtered_icons:
        cx, cy = _bbox_center(b)
        sx, sy = int(round(cx * scale_x)), int(round(cy * scale_y))
        elems.append(Element(idx=idx, kind="icon", bbox_img=b, center_img=(cx, cy), center_screen=(sx, sy), text="", conf=conf))
        idx += 1

    annotated = draw_numbered_boxes(img, elems)
    return annotated, elems


def draw_numbered_boxes(img: Image.Image, elems: list[Element]) -> Image.Image:
    out = img.copy()
    draw = ImageDraw.Draw(out)
    w, h = out.size
    thick = max(2, int(round(max(w, h) / 600)))
    pad = max(2, int(round(max(w, h) / 450)))
    font_size = max(12, int(round(max(w, h) / 70)))

    try:
        font = ImageFont.truetype("arial.ttf", font_size)
    except Exception:
        font = ImageFont.load_default()

    for e in elems:
        x1, y1, x2, y2 = e.bbox_img
        draw.rectangle([x1, y1, x2, y2], width=thick, outline="red")
        label = str(e.idx)
        # textbbox returns (l,t,r,b)
        tb = draw.textbbox((0, 0), label, font=font)
        tw, th = tb[2] - tb[0], tb[3] - tb[1]
        bx1, by1 = x1, max(0, y1 - th - 2 * pad)
        bx2, by2 = x1 + tw + 2 * pad, y1
        draw.rectangle([bx1, by1, bx2, by2], fill="red")
        draw.text((x1 + pad, by1 + pad), label, fill="white", font=font)

    return out


def format_lines(elems: list[Element]) -> list[str]:
    lines = []
    for e in elems:
        x1, y1, x2, y2 = e.bbox_img
        cx, cy = e.center_screen
        if e.kind == "text":
            lines.append(f"{e.idx}. ({cx},{cy}) text \"{e.text}\" bbox=({x1},{y1},{x2},{y2})")
        else:
            lines.append(f"{e.idx}. ({cx},{cy}) icon conf={e.conf:.2f} bbox=({x1},{y1},{x2},{y2})")
    return lines
