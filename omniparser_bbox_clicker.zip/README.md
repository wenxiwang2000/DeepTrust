# OmniParser Bounding Box Click Helper (Local)

Small GUI tool that uses **OmniParser's icon detector (YOLO) weights** + **OCR** to:
- Load a screenshot image (full desktop screenshot recommended)
- Detect **text boxes** (EasyOCR) and **icon/interactable regions** (OmniParser YOLO detector)
- Draw numbered bounding boxes on the image
- Export a `.txt` file listing each ID, **mouse-move coordinate (x,y)** (center point), and box corners

## Output
- `annotated.png` with numbered boxes
- `boxes.txt` with lines like:
  `12. (1130,300) icon conf=0.82 bbox=(1098,260,1164,340)`
  `13. (820,745) text "Recycle Bin" bbox=(780,730,860,760)`

Coordinates are mapped to your **current screen size**. If your image is a full-screen screenshot, mapping is accurate.

## Install
Double-click `run.bat`.

> If PyTorch install fails, install it from the official PyTorch site, then re-run `run.bat`.

## Download OmniParser weights (required)
Double-click `download_weights.bat`.

This uses the official weights repo `microsoft/OmniParser-v2.0` and follows the weights layout in the OmniParser docs:
`weights/icon_detect/model.pt` must exist.

## Attribution
OmniParser: microsoft/OmniParser (CC BY 4.0). This tool is a thin wrapper around their icon detector weights layout + OCR.
